package com.example.bnr_motorcycle

data class Motorcycle(val name: String, val imageResId: Int)

